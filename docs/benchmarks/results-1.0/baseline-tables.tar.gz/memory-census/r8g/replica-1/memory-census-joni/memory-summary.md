# RE2 And Joni Memory Census

Ratios are RE2 bytes divided by Joni bytes; lower is better. Caller-owned input bytes are excluded.

## Summary

| Lifecycle | Rows | Median | P90 | Maximum |
|---|---:|---:|---:|---:|
| active-matcher | 10 | 0.542x | 1.101x | 1.103x |
| compiled | 15 | 1.083x | 3.127x | 3.318x |
| warm-pattern | 80 | 0.272x | 0.670x | 1.160x |

## Largest Ratios

| Workload | Source | Lifecycle | Operation | Roots | RE2 | Joni | Ratio | Difference |
|---|---:|---|---|---:|---:|---:|---:|---:|
| captureSparse | 0 | compiled | none | 64 | 3254.75 | 981.0 | 3.318x | 2273.75 |
| emptyMatches | 0 | compiled | none | 64 | 1466.75 | 469.0 | 3.127x | 997.75 |
| literalSparse | 0 | compiled | none | 64 | 2101.0 | 829.0 | 2.534x | 1272.0 |
| unicodeSparse | 0 | compiled | none | 64 | 2022.375 | 861.0 | 2.349x | 1161.375 |
| delimiterDense | 0 | compiled | none | 64 | 1528.0 | 773.0 | 1.977x | 755.0 |
| captureSparse | 0 | compiled | none | 8 | 3358.0 | 2080.0 | 1.614x | 1278.0 |
| captureSparse | 32768 | warm-pattern | replace-lambda | 1 | 12608 | 10872 | 1.160x | 1736 |
| captureSparse | 1024 | warm-pattern | replace-lambda | 1 | 12584 | 10872 | 1.157x | 1712 |
| literalSparse | 0 | compiled | none | 8 | 2192.0 | 1928.0 | 1.137x | 264.0 |
| captureSparse | 32768 | active-matcher | find-all | 1 | 12744 | 11552 | 1.103x | 1192 |

## Material Outliers

No row exceeded both 2x Joni memory and 1 MiB of absolute excess.
